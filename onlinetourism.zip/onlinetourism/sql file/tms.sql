-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 20, 2019 at 10:18 PM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `updationDate` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', 'bfd6276916f30b046226cf7f5cdb6cd6', '2022-05-13 11:18:49');

-- --------------------------------------------------------

--
-- Table structure for table `tblbooking`
--

CREATE TABLE `tblbooking` (
  `BookingId` int(11) NOT NULL,
  `PackageId` int(11) DEFAULT NULL,
  `UserEmail` varchar(100) DEFAULT NULL,
  `FromDate` varchar(100) DEFAULT NULL,
  `ToDate` varchar(100) DEFAULT NULL,
  `PaymentMode` varchar(100) DEFAULT NULL,
  `Comment` mediumtext DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  `status` int(11) DEFAULT NULL,
  `CancelledBy` varchar(5) DEFAULT NULL,
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbooking`
--

INSERT INTO `tblbooking` (`BookingId`, `PackageId`, `UserEmail`, `FromDate`, `ToDate`, `PaymentMode`,`Comment`, `RegDate`, `status`, `CancelledBy`, `UpdationDate`) VALUES
(2, 1, 'anuj@gmail.com', '05/18/2017', '05/31/2017','card', '\"Please book shimla-manali package for a group of three people ', '2022-05-13 19:01:10', 2, 'u', '2022-05-13 21:30:23'),
(3, 2, 'anuj@gmail.com', '05/16/2017', '05/31/2017','card', 'book a kashmir trip package for month-end.', '2022-05-13 20:20:01', 2, 'a', '2022-05-13 23:04:40'),
(4, 1, 'anuj@gmail.com', '05/16/2017', '05/31/2017','upi', 'book a solo shimla-manali package.', '2022-05-13 20:32:54', 2, 'a', '2022-05-13 21:36:39'),
(5, 1, 'anuj@gmail.com', '05/16/2017', '05/31/2017','card', 'book a solo shimla-manali package', '2022-05-13 20:33:17', 2, 'a', '2022-07-20 20:02:42'),
(6, 2, 'anuj@gmail.com', '05/14/2017', '05/24/2017','card', ' demo package', '2022-05-13 21:18:37', 2, 'a', '2022-05-14 07:58:28'),
(7, 4, 'sarita@gmail.com', '05/26/2017', '05/30/2017','upi', 'i would like to book kerla package our for family of five.', '2022-05-14 05:09:11', 2, 'a', '2022-05-14 07:47:39'),
(8, 2, 'sarita@gmail.com', '05/27/2017', '05/28/2017','paytm','Book kashmir package with offers', '2022-05-14 05:10:24', 2, 'a', '2022-05-14 05:13:03'),
(9, 1, 'demo@test.com', '05/19/2017', '05/21/2017', 'paytm','demo book shimla-manali package.', '2022-05-14 07:45:11', 1, NULL, '2022-05-14 07:47:45'),
(10, 5, 'abc@g.com', '05/22/2017', '05/24/2017', 'other','book a coorg package tour for family.', '2022-05-14 07:56:26', 1, NULL, '2022-05-14 07:58:19'),
(11, 4, 'anuj@gmail.com', '2019-07-31', '2019-08-02', 'paytm','This is sample text for testing,', '2019-07-20 20:15:35', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblenquiry`
--

CREATE TABLE `tblenquiry` (
  `id` int(11) NOT NULL,
  `FullName` varchar(100) DEFAULT NULL,
  `EmailId` varchar(100) DEFAULT NULL,
  `MobileNumber` char(10) DEFAULT NULL,
  `Subject` varchar(100) DEFAULT NULL,
  `Description` mediumtext DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `Status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblenquiry`
--

INSERT INTO `tblenquiry` (`id`, `FullName`, `EmailId`, `MobileNumber`, `Subject`, `Description`, `PostingDate`, `Status`) VALUES
(1, 'anuj', 'anuj.lpu1@gmail.com', '2354235235', 'To check availability of shimla tour package','shimla tour package is needed in month of june', '2022-05-13 22:23:53', 1),
(2, 'sanvi', 'sanvi@gmail.com', '3454353453', 'availability of hotels', 'We needed to enquire about availability of hotel rooms in coorg', '2022-05-13 22:27:00', 1),
(3, 'ria', 'ria3@hdhdhqw.com', '8888888888', 'new packages and offers', 'I needed to enquire about new packages and offers for those packages in your agency', '2022-05-13 22:28:11', 1),
(4, 'Teesha', 'teesha@gm.com', '4747474747', 'booking status', 'To check my booking status', '2022-05-14 07:54:07', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblissues`
--

CREATE TABLE `tblissues` (
  `id` int(11) NOT NULL,
  `UserEmail` varchar(100) DEFAULT NULL,
  `Issue` varchar(100) DEFAULT NULL,
  `Description` mediumtext DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `AdminRemark` mediumtext DEFAULT NULL,
  `AdminremarkDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblissues`
--

INSERT INTO `tblissues` (`id`, `UserEmail`, `Issue`, `Description`, `PostingDate`, `AdminRemark`, `AdminremarkDate`) VALUES
(4, 'anuj@gmail.com', 'Cancellation', 'I want to cancel my coorg tour booking due to some emergency.  ', '2022-05-13 22:03:33', 'Cancellation request is in proceed', '2022-05-13 23:50:40'),
(5, 'sarita@gmail.com', 'Cancellation', 'Please cancel my hotel room bookings .', '2022-05-14 05:12:14', 'Bookings are cancelled ', '2022-05-14 07:52:07'),
(6, 'demo@test.com', 'Refund', 'I would like to bring to your notice that i still have nt received my refund for cancelllation of goa tour package.please refund my amount as soon as possible', '2022-05-14 07:45:37', NULL, '0000-00-00 00:00:00'),
(7, 'abc@g.com', 'Refund', 'My amount for group package tour has to be refunded.', '2022-05-14 07:56:46', NULL, '2022-05-14 07:58:43');

-- --------------------------------------------------------

--
-- Table structure for table `tblpages`
--

CREATE TABLE `tblpages` (
  `id` int(11) NOT NULL,
  `type` varchar(255) DEFAULT '',
  `detail` longtext DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpages`
--

INSERT INTO `tblpages` (`id`, `type`, `detail`) VALUES
(1, 'Terms', '<P align=justify><FONT size=2><STRONG><FONT color=#990000>(1) ACCEPTANCE OF TERMS</FONT><BR><BR></STRONG>This is a user agreement along with terms of service. The user should refer to the relevant Terms of Service applicable for the given booking and packages.The user must be atlest 18 years and above for booking and transaction. User should not violate any of the laws abiding the govt. Users are advised to check the description and properties of booking before making a booking.Online travel portal considers security of usets as their first priority.all the data shared is kept secured. '),
(2, 'Privacy', '<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">Online travel portal recognises the importance of privacy of its users and also maintaining the confidentiality of the information provided by the users as a responsible data controller and data processor. This policy is applicable to any user who book packages or intend to book or enquire about any service provided by us.This privacy policy is an intergral part of  your User agreement with Online travel portal.</span>'),
(3, 'aboutus', '										<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">Online travel portal is efficient to use , online platform to book travel and tourism packages with wide variety of offers and minimal expenses. It is a responsive system that provides a wide variety of packages with numerous facilities to its users..</span>'),
(11, 'Contact', '										<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">Office-address:#33,OTP main office, carter road, Mumbai . Phone no:454545466 </span>');

-- --------------------------------------------------------

--
-- Table structure for table `tbltourpackages`
--

CREATE TABLE `tbltourpackages` (
  `PackageId` int(11) NOT NULL,
  `PackageName` varchar(200) DEFAULT NULL,
  `PackageType` varchar(150) DEFAULT NULL,
  `PackageLocation` varchar(100) DEFAULT NULL,
  `PackagePrice` int(11) DEFAULT NULL,
  `PackageFetures` varchar(255) DEFAULT NULL,
  `PackageDetails` mediumtext DEFAULT NULL,
  `PackageImage` varchar(100) DEFAULT NULL,
  `Creationdate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltourpackages`
--

INSERT INTO `tbltourpackages` (`PackageId`, `PackageName`, `PackageType`, `PackageLocation`, `PackagePrice`, `PackageFetures`, `PackageDetails`, `PackageImage`, `Creationdate`, `UpdationDate`) VALUES
(1, 'Shimla-Manali ', 'General', 'Kullu, Manali ,Shimla-India', 6000, 'Snow skating, skiing,Amazing sight view', ' Resorts with scenic hillview, amazing cuisines and lots of adventurous activities .Travel fare and pick up and drop facilities provided.', 'ma.png', '2022-05-13 14:23:44', '2022-05-13 17:51:01'),
(2, 'Enchanting-Kashmir ', 'Special', 'Jammu & Kashmir, India', 7500, 'Mountain view,Himalayan experience ', ' Amazing boating experience in Dal lake, valley of flowers. Travel charges (airfare), accomodation and food included. ', 'jk.png', '2022-05-13 15:24:26', '2022-05-13 17:51:57'),
(3, 'Divine-TamilNadu', 'Family', 'Tamil Nadu,India', 4500, 'All historic and spiritual pilgrim places', 'Temple visit , explore architectures and sculptures. Relish tasty south indian dishes.', 'tn.png', '2019-05-13 16:00:58', '2019-07-20 20:12:41'),
(4, 'Kerala', 'Familty and Couple', 'Kerala,India', 7000, ' Adventurous activities along with forest safari', ' Travel fare included(travel in golden express train with economic class seats), Homestays near backwaters of munnar, delicious kerala food, boat riding and kayaking\"', 'ker.jpg', '2022-05-13 22:39:37', '0000-00-00 00:00:00'),
(5, 'Coorg ', 'General', 'Coorg,Karnataka', 3000, 'Elephant rides and exciting activities and sunset point ', 'Extravagant resorts stay near brahmagiri hills and trekking , boating and river rafting activities included ', 'coorg.png', '2022-05-13 22:42:10', '0000-00-00 00:00:00'),
(6, 'Goa', 'Group', 'Goa, India', 5000, 'Free pickup , drop , including lots of beach activities', 'New year festivals and carnivals, serene beaches and adventure activities , aguada fort and catholic church visit','goa.png','2022-04-12 22:32:10','0000-00-00 00:00:00');
-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL,
  `FullName` varchar(100) DEFAULT NULL,
  `MobileNumber` char(10) DEFAULT NULL,
  `EmailId` varchar(70) DEFAULT NULL,
  `Password` varchar(100) DEFAULT NULL,
  `RegDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `FullName`, `MobileNumber`, `EmailId`, `Password`, `RegDate`, `UpdationDate`) VALUES
(1, 'Anuj kumar', '1111111111', 'anuj@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2022-05-10 10:38:17', '2022-07-20 20:18:18'),
(3, 'sarita', '9999999999', 'sarita@gmail.com', '5c428d8875d2948607f3e3fe134d71b4', '2022-05-10 10:50:48', '2022-05-14 07:40:19'),
(7, 'test', '7676767676', 'test@gm.com', 'f925916e2754e5e03f75dd58a5733251', '2022-05-10 10:54:56', '0000-00-00 00:00:00'),
(8, 'Anusha kumar', '9999999999', 'demo@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2022-05-14 07:17:44', '0000-00-00 00:00:00'),
(9, 'XYZabc', '3333333333', 'xyz@gmail.com', 'f925916e2754e5e03f75dd58a5733251', '2022-05-14 07:25:13', '2022-05-14 07:25:42'),
(10, ' Kumar', '4543534534', 'demo@test.com', 'f925916e2754e5e03f75dd58a5733251', '2022-05-14 07:43:23', '2022-05-14 07:46:57'),
(11, 'XYZ', '8888888888', 'abc@g.com', 'f925916e2754e5e03f75dd58a5733251', '2022-05-14 07:54:32', '2022-05-14 07:55:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbooking`
--
ALTER TABLE `tblbooking`
  ADD PRIMARY KEY (`BookingId`);

--
-- Indexes for table `tblenquiry`
--
ALTER TABLE `tblenquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblissues`
--
ALTER TABLE `tblissues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblpages`
--
ALTER TABLE `tblpages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbltourpackages`
--
ALTER TABLE `tbltourpackages`
  ADD PRIMARY KEY (`PackageId`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `EmailId` (`EmailId`),
  ADD KEY `EmailId_2` (`EmailId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblbooking`
--
ALTER TABLE `tblbooking`
  MODIFY `BookingId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tblenquiry`
--
ALTER TABLE `tblenquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblissues`
--
ALTER TABLE `tblissues`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tblpages`
--
ALTER TABLE `tblpages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbltourpackages`
--
ALTER TABLE `tbltourpackages`
  MODIFY `PackageId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;



COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
