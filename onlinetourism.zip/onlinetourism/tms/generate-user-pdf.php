<?php
include "C:\\xamp\htdocs\onlinetourism\\tms\includes\dbconfig.php";
include_once('C:\xamp\htdocs\onlinetourism\pdf\fpdf.php');
$display_heading = array('BookingId'=>'ID','PackageId'=>'PackId','UserEmail'=>'Email','FromDate'=>'From','ToDate'=>'To','PaymentMode'=>'Payment','RegDate'=>'BookingDate','status'=>'Status','CancelledBy'=>'Cancel');
$result = mysqli_query ($conn, "SELECT BookingId,PackageId,UserEmail,FromDate,ToDate,PaymentMode,RegDate,status,CancelledBy FROM tblbooking ") or die("database error:".mysqli_error($conn));
$header= mysqli_query($conn,"SHOW columns FROM  tblbooking WHERE  field!='Comment' and field!='UpdationDate' ");
class PDF extends FPDF{
    function Header() {
       $this->Image('C:\xamp\htdocs\onlinetourism\tms\images\logo.jpg', 10,6,25);
       $this->SetFont('Arial','B',13);
       $this->Cell(80);
       $this->Cell(80,10,'Travel History',1,0,'C');
       $this->Ln(20);
    }
    function Footer() {
       $this->SetY(-15);
       $this->SetFont('Arial','I',8);
       $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
    }
}
$pdf = new PDF();
$pdf->AddPage();
$pdf->AliasNbPages();
$pdf->SetFont('Arial','B',8);
foreach($header as $heading) {
   $pdf->Cell(22,10,$display_heading[$heading['Field']],1);

}
foreach($result as $row) {
    $pdf->SetFont('Arial','',6);
    $pdf->Ln();
    foreach($row as $column)
        $pdf->Cell(22,10,$column,1);
}

$pdf->Output();
?>